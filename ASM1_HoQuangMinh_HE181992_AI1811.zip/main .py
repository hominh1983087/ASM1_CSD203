class Node:
    def __init__(self, bid, title, author, status):
        self.bid = bid
        self.title = title
        self.author = author
        self.status = status
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def add_book(self, bid, title, author, status):
        new_node = Node(bid, title, author, status)
        if self.head is None:
            self.head = new_node
        else:
            current_node = self.head
            while current_node.next is not None:
                current_node = current_node.next
            current_node.next = new_node

    def view_books(self):
        print("\nBid    | Title                | Author               | Status")
        print("-" * 60)
        current_node = self.head
        while current_node is not None:
            print(f"{current_node.bid:6} | {current_node.title:20} | {current_node.author:20} | {current_node.status}")
            current_node = current_node.next

    def delete_book(self, bid):
        current_node = self.head
        prev_node = None
        while current_node is not None and current_node.bid != bid:
            prev_node = current_node
            current_node = current_node.next
        if current_node is not None:
            if prev_node is None:
                self.head = current_node.next
            else:
                prev_node.next = current_node.next

    def borrow_book(self, bid):
        current_node = self.head
        while current_node is not None and current_node.bid != bid:
            current_node = current_node.next
        if current_node is not None and current_node.status == "0":
            current_node.status = "1"

    def return_book(self, bid):
        current_node = self.head
        while current_node is not None and current_node.bid != bid:
            current_node = current_node.next
        if current_node is not None and current_node.status == "1":
            current_node.status = "0"

def main():
    library = LinkedList()

    while True:
        # Hiển thị menu và lấy lựa chọn
        print("\nLibrary Management System")
        print("1. Add Book")
        print("2. View Books")
        print("3. Delete Book")
        print("4. Borrow Book")
        print("5. Return Book")
        print("6. Exit")

        choice = int(input("Enter your choice: "))

        if choice == 1:
            bid = input("Enter book ID: ")
            title = input("Enter book title: ")
            author = input("Enter book author: ")
            status = "0"  # Initially available
            library.add_book(bid, title, author, status)
        elif choice == 2:
            library.view_books()
        elif choice == 3:
            bid = input("Enter book ID to delete: ")
            library.delete_book(bid)
        elif choice == 4:
            bid = input("Enter book ID to borrow: ")
            library.borrow_book(bid)
        elif choice == 5:
            bid = input("Enter book ID to return: ")
            library.return_book(bid)
        elif choice == 6:
            print("Exiting...")
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()